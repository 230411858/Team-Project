<img src="{{ asset('images/GamerHubLogo.png') }}" alt="Logo" style="width: 200px; height: auto;" {{ $attributes }}>
