<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(url('/css/reuse.css')); ?>">

<style>
    .product-list {
        display: flex;
        flex-wrap: wrap;
        gap: 20px;
        padding: 150px;
    }

    .product {
        width: 30%;
        background-color: #f9f9f9;
        border-radius: 8px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        overflow: hidden;
        transition: transform 0.3s ease;
        padding: 15px;
    }

    .product-card {
        text-decoration: none;
        color: #000;
        display: block;
    }

    .product-card:hover {
        transform: scale(1.05);
    }

    .product h2 {
        font-size: 1.2rem;
        margin-bottom: 20px;
    }

    .product p {
        font-size: 1rem;
        margin-bottom: 10px;
    }

    .product-image {
        width: 100%;
        height: auto;
        border-radius: 5px;
        margin-bottom: 10px;
    }

    h1 {
        padding: 20px;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
<title>Search Results</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h1>Search Results for "<?php echo e($query); ?>"</h1>

<?php if($products->isEmpty()): ?>

<h1>No Products Found</h1>

<?php else: ?>
<div class="product-list">
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
    $image = \App\Models\ProductImage::firstWhere('product', $product->id);
    ?>
    <div class="product">
        <a href="<?php echo e(url('/products')); ?>/<?php echo e($product->id); ?>" class="product-card">
            <div class="card-content">

                <!-- Display Product Image -->
                <img src="<?php echo e(url('/images')); ?>/<?php echo e($product->category); ?>/<?php echo e($image == null ? 'cover.png' : $image->file); ?>"
                    alt="Default Image" class="product-image">

                <h2><?php echo e($product->name); ?></h2>
                <p>Price: £<?php echo e($product->price / 100); ?></p>
                <p><?php echo e($product->description); ?></p>

            </div>
        </a>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\GitHubDesktop\Team-Project\GamerHub\resources\views/products/search-results.blade.php ENDPATH**/ ?>