<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(url('/css/deals.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
<title>Deals | GAMERHUB</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="cart">
    <h2 class="cart-title">Your Cart</h2>
    <div class="cart-content"></div>
    <div class="total">
        <div class="total-title">Total</div>
        <div class="total-price">$0</div>
    </div>
    <button class="cart_btn-buy">more info</button>
    <i class="ri-close-line" id="cart-close"></i>
</div>
<section id="countdown" class="countdown">
    <div class="countdown_background">
        <div class="countdown_container">
            <?php
            $biggest_discount = $discount_items->sortByDesc('discount')->first();

            $biggest_discount_image = $images->firstWhere('product', $biggest_discount->id);
            
            ?>
            <img src="<?php echo e(url('/images')); ?>/<?php echo e($biggest_discount->category); ?>/<?php echo e($biggest_discount_image == null ? 'cover.png' : $biggest_discount_image->file); ?>" alt="" />
            <div class="countdown-text">
                <h1><b><?php echo e($biggest_discount->discount * 100); ?>% off</b></h1>
                <p class="product-price">£<?php echo e(number_format($biggest_discount->price / 100, 2)); ?></p>
                <p class="product-price">£<?php echo e(number_format(($biggest_discount->price * (1 - $biggest_discount->discount)) / 100, 2)); ?></p>
                <h2><b>Limited Deal: <br> Don't miss out!</b></h2>
                <div class="countdown_time">
                    <div>
                        <p id="days">00</p>
                        <span>Days</span>
                    </div>
                    <div>
                        <p id="hours">00</p>
                        <span>Hours</span>
                    </div>
                    <div>
                        <p id="minutes">00</p>
                        <span>Minutes</span>
                    </div>
                    <div>
                        <p id="seconds">00</p>
                        <span>Seconds</span>
                    </div>
                </div>
                <button type="button" class="btn-cart">
                    add to cart
                    <span><i class="fas fa-plus"></i></span>
                </button>
            </div>
        </div>
    </div>
</section>
<section id="catalogue" class="catalogue">
    <div class="products">
        <div class="container">
            <h1 class="cata-title">DEALS OF THE MOMENT</h1>

            <div class="product-items">
                <?php $__currentLoopData = $discount_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discount_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- single product -->
                <div class="product">
                    <div class="product-content">
                        <div class="product-img">
                            <?php
                            $image = $images->firstWhere('product', $discount_item->id);
                            ?>
                            <a href="<?php echo e(url('/products')); ?>/<?php echo e($discount_item->id); ?>">
                                <img src="<?php echo e(url('/images')); ?>/<?php echo e($discount_item->category); ?>/<?php echo e($image == null ? 'cover.png' : $image->file); ?>" alt="Product Image" />
                            </a>
                        </div>
                        <div class="product-btns">
                            <button type="button" class="btn-cart">
                                add to cart
                                <span><i class="fas fa-plus"></i></span>
                            </button>
                            <button type="button" class="btn-buy">
                                more info
                            </button>
                        </div>
                    </div>

                    <div class="product-info">
                        <a href="<?php echo e(url('/products')); ?>/<?php echo e($discount_item->id); ?>" class="product-name"><?php echo e($discount_item->name); ?></a>
                        <p class="product-price">£<?php echo e(number_format($discount_item->price / 100, 2)); ?></p>
                        <p class="product-price">£<?php echo e(number_format(($discount_item->price * (1 - $discount_item->discount))/ 100, 2)); ?></p>
                    </div>

                    <div class="off-info">
                        <h2 class="sm-title"><?php echo e($discount_item->discount * 100); ?>% off</h2>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(url('/js/deals.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\GitHubDesktop\Team-Project\GamerHub\resources\views/deals.blade.php ENDPATH**/ ?>