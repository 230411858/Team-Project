<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(url('/css/product.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
<title><?php echo e(ucwords($product->name)); ?> | GAMERHUB</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<nav>
    <ul class="breadcrumb">
        <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
        <li><a href="<?php echo e(url('/')); ?>/products/category/<?php echo e($product->category); ?>"><?php echo e(ucfirst($product->category)); ?></a></li>
        <li><?php echo e(ucwords($product->name)); ?></li>
    </ul>
</nav>

<!-- Products part -->
<h1 class="name-p"><?php echo e(ucwords($product->name)); ?></h1>

<div class="page-p container">


    <div class="main-p">

        <div class="images-p">

            <!-- main picture (big one) -->
            <?php
            $image = $images->firstWhere('product', $product->id);

            $file = 'cover.png';

            if ($image != null)
            {
            $file = $image->file;
            }
            ?>
            <div class="image-main-p">
                <img src="<?php echo e(url('/images')); ?>/<?php echo e($product->category); ?>/<?php echo e($file); ?>" alt="Product Image" id="Mainpicture">
            </div>

            <!-- little thumbnails to click to change pics-->
            <div class="thumbnails">
                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $file = "$product->category/$image->file"
                ?>
                <img src="<?php echo e(url('/images')); ?>/<?php echo e($file); ?>" alt="thumbnail1" onclick="changeImage('<?php echo e(url('/')); ?>/images/<?php echo e($file); ?>')">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <div class="details-p">
            <p class="description-p">
                <?php echo e($product->description); ?>

            </p>
            <?php if($product->discount > 0): ?>
            <p class="price-p">Price: <s style="color: red;">£<?php echo e(number_format(($product->price / 100), 2)); ?></s> > <span style="color: green;">£<b id="price"><?php echo e(number_format(($product->price / 100) * (1 - $product->discount), 2)); ?></b></span></p>
            <?php else: ?>
            <p class="price-p">Price: £<span id="price"><?php echo e(number_format(($product->price / 100), 2)); ?></span></p>
            <?php endif; ?>
            <?php if($product->stock < 10): ?>
                <p id="low-stock">Low Stock!</p>
                <?php else: ?>
                <p id="in-stock">In Stock!</p>
                <?php endif; ?>

                <div class="quantity-section">
                    <input hidden type="number" id="product-id" name="product" value="<?php echo e($product->id); ?>">
                    <label for="quantity">Quantity:</label>
                    <input type="number" id="quantity" name="quantity" value="1" min="1" onchange="updateTotal()">
                    £<span id="total"><?php echo e(number_format(($product->price * (1 - $product->discount) / 100), 2)); ?></span>
                    <button class="cart-butt" aria-label="Add to Cart" onclick="addToCart()">Add to Cart</button>
                </div>

                <!-- description on the right -->
                <div class="extra-info">
                    <div class="info-section">
                        <h3>Free Shipping and Returns</h3>
                        <p>Experience peak comfort and performance with our wireless mouse...</p>
                        <!-- add to cart button -->
                    </div>

                    <br>


                    <div class="specs-main">
                        <button type="button" class="spec-det">Specs & Details</button>
                        <div class="specstable">
                            <ul>
                                <li>Height: 132.5 mm</li>
                                <li>Width: 99.8 mm</li>
                                <li>Depth: 51.4 mm</li>
                                <li>Weight: 164 g</li>
                            </ul>
                        </div>
                        <!-- spec button -->
                        <br> <br>
                    </div>
                    <div class="compat-main">
                        <button type="button" class="compat-js">Compatibility</button>
                        <div class="compat">
                            <br>
                            <ul>
                                <li>Windows 10 or later</li>
                                <li>macOS 12 or later</li>
                                <li>Linux</li>
                            </ul>
                            <!-- compatibility button -->
                        </div>
                    </div>
                </div>
        </div>
    </div>
</div>
</div>
<!-- full container for right side -->

<div class="reviews-section container">
    <h2>Customer Reviews</h2>

    <h2>Write a Review</h2>

    <form class="review-form" action="<?php echo e(url('/review')); ?>/<?php echo e($product->id); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="star_rating">
            <button type="button" class="star" data-value="1">&#9734;</button>
            <button type="button" class="star" data-value="2">&#9734;</button>
            <button type="button" class="star" data-value="3">&#9734;</button>
            <button type="button" class="star" data-value="4">&#9734;</button>
            <button type="button" class="star" data-value="5">&#9734;</button>
            <input type="number" id="rating" name="rating" hidden value="3">
        </div>
        <br>
        <div class="review-form">
            <input type="text" maxlength="1000" id="text" name="text" rows="4" placeholder="Write your review here...">
            <button class="submit-review" type="submit">Submit Review</button>
    </form>
</div>

<div class="reviews-list" id="reviews-list">
    <?php if($reviews->isEmpty()): ?>
    <p id="no-reviews-message">No reviews yet. Please leave a review</p>
    <?php else: ?>
    <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="review-item">
        <strong><?php echo e(\App\Models\User::find($review->user)->name); ?></strong>
        <div class="review-stars">
            <?php for($i = $review->rating; $i > 0; $i--): ?>
            <button type="button" class="static-star">&#9733;</button>
            <?php endfor; ?>
            <?php for($i = 5; $i > $review->rating; $i--): ?>
            <button type="button" class="static-star">&#9734;</button>
            <?php endfor; ?>
        </div>
        <p><?php echo e($review->text); ?></p>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div>
</div>
<?php $__env->stopSection(); ?>
<!-- reviews section -->
<style>
    #low-stock {
        color: red;


    }

    #in-stock {
        color: green;

    }
</style>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(url('/js/product.js')); ?>"></script>
<script src="https://kit.fontawesome.com/6d6a721856.js" crossorigin="anonymous"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\GitHubDesktop\Team-Project\GamerHub\resources\views/products/show.blade.php ENDPATH**/ ?>