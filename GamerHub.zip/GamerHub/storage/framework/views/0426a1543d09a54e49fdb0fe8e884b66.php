

<?php $__env->startSection('css'); ?>
<style>
    .content-section {
        padding: 40px 0;
    }

    .container {
        max-width: 1200px;
        margin: auto;
        padding: 0px 20px;
    }

    .card {
        background: white;
        border-radius: 8px;
        box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        padding: 20px;
    }

    .card-body {
        padding: 20px;
    }

    .section-title {
        font-size: 24px;
        font-weight: bold;
        margin-bottom: 20px;
    }

    .success-message {
        color: green;
        font-weight: bold;
        margin-bottom: 15px;
    }

    .inventory-table {
        width: 100%;
        border-collapse: collapse;
    }

    .inventory-table th,
    .inventory-table td {
        padding: 12px;
        border-bottom: 1px solid #ddd;
        text-align: left;
    }

    .inventory-table th {
        background: #f8f8f8;
    }

    .edit-button,
    .delete-button {
        padding: 6px 12px;
        border-radius: 5px;
        text-decoration: none;
        cursor: pointer;
        transition: background 0.3s ease-in-out;
    }

    .edit-button {
        color: white;
        background-color: #007bff;
    }

    .edit-button:hover {
        background-color: #0056b3;
    }

    .delete-button {
        color: white;
        background-color: #dc3545;
        border: none;
    }

    .delete-button:hover {
        background-color: #c82333;
    }

    .inline-form {
        display: inline;
    }

    .row:hover {
        color: white;
        background-color: orange;
        cursor: pointer;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
<title>Orders | GamerHub</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-section">
    <div class="container">
        <div class="card">
            <div class="card-body">
                <?php if(Auth::user()->account_type === 'admin'): ?>
                <h3 class="section-title">All Orders</h3>
                <?php else: ?>
                <h3 class="section-title">My Orders</h3>
                <?php endif; ?>
                <table class="inventory-table">
                    <thead>
                        <tr>
                            <th>Order #</th>
                            <th>Date</th>
                            <th>Email</th>
                            <th>Shipping Method</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(url('/orders')); ?>/<?php echo e($order->id); ?>">
                            <tr class="row" onclick="window.location='/orders/<?php echo $order->id ?>'">
                                <td><?php echo e($order->id); ?></td>
                                <td><?php echo e($order->created_at); ?></td>
                                <td><?php echo e($order->email); ?></td>
                                <td><?php echo e(ucwords($order->shipping_method)); ?></td>
                                <td><?php echo e(ucwords($order->status)); ?></td>
                            </tr>
                        </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\GitHubDesktop\Team-Project\GamerHub\resources\views/orders/index.blade.php ENDPATH**/ ?>