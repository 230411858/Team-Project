<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(url('/css/front.css')); ?>">
<style>
  .unclickable {
    pointer-events: none;
  }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
<title>Welcome | GamerHub</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="hero">
  <div class="hero_background">
    <div class="hero_container">
      <img src="<?php echo e(url('/images/hero_image.png')); ?>" alt="">
      <div class="hero-text">
        <h1><b>The way to <span>compete</span> with excellence</b></h1>
        <a href="<?php echo e(url('/deals')); ?>"><button id="hero_button">Discover our Offers</button></a>
      </div>
    </div>
  </div>
</section>
<h1 class="lg-title">Our best sellers</h1>
<section class="slider">
  <input type="radio" name="position" checked />
  <input type="radio" name="position" />
  <input type="radio" name="position" />
  <input type="radio" name="position" />
  <input type="radio" name="position" />
  <input type="radio" name="position" />
  <main id="carousel">
    <?php $__currentLoopData = $discount_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discount_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
    $image = $images->firstWhere('product', $discount_item->id);
    ?>
    <div class="item">
      <div class="product">
        <div class="product-content">
          <div class="product-img">
            <a href="<?php echo e(url('/products')); ?>/<?php echo e($discount_item->id); ?>">
            <img src="<?php echo e(url('/images')); ?>/<?php echo e($discount_item->category); ?>/<?php echo e($image == null ? 'cover.png' : $image->file); ?>" alt="product image" />
            </a>
          </div>
          <div class="product-btns">
            <a href="<?php echo e(url('/add')); ?>/<?php echo e($discount_item->id); ?>"><button type="button" class="btn-cart">add to cart></button></a>
            <button onclick="window.location.href = '/products/<?php echo $discount_item->id ?>'" type="button" class="btn-buy">more info</button>
          </div>
        </div>

        <div class="product-info">
          <a href="<?php echo e(url('/products')); ?>/<?php echo e($discount_item->id); ?>" class="product-name"><?php echo e($discount_item->name); ?></a>
          <p class="product-price">£<?php echo e($discount_item->price / 100); ?></p>
          <p class="product-price">£<?php echo e(number_format(($discount_item->price * (1 - $discount_item->discount)) / 100, 2)); ?></p>
        </div>

        <div class="off-info">
          <h2 class="sm-title"><?php echo e($discount_item->discount * 100); ?>% off</h2>
        </div>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </main>
</section>
<section class="reason">
  <div class="reason-content">
    <p><b>Buying on GamerHub has loads of perks</b></p>
  </div>
  <div class="reason-content">
    <div class="icones">
      <a class="unclickable" href="#"><i class='bx bxs-package'></i></a>
    </div>
    <a class="unclickable"><b>Fast shipping</b> across the UK</a>
  </div>
  <div class="reason-content">
    <div class="icones">
      <a class="unclickable" href="#"><i class='bx bx-check-shield'></i></a>
    </div>
    <a class="unclickable"><b>Extended warranty</b> with <b>a 30 day</b> money back guarantee.</a>
  </div>

  <div class="reason-content">
    <div class="icones">
      <a class="unclickable" href="#"><i class='bx bx-credit-card'></i></a>
    </div>
    <a class="unclickable"><b>Pay in three</b> with <b>no interest</b></a>
  </div>
</section>
<section class="layout">
  <h1 class="cata-title"><b>CATALOGUE</b></h1>
  <div class="feed">
    <a href="<?php echo e(url('/products/category/monitors')); ?>" class="type_card">
      <p class="type_card__title">Monitors</p>
    </a>
    <a href="<?php echo e(url('/products/category/speakers')); ?>" class="type_card">
      <p class="type_card__title">Speakers</p>
    </a>
    <a href="<?php echo e(url('/products/category/mice')); ?>" class="type_card">
      <p class="type_card__title">Mice</p>
    </a>
    <a href="<?php echo e(url('/deals')); ?>" class="type_card">
      <p class="type_card__title">Discounted</p>
    </a>
    <a href="<?php echo e(url('/products/category/keyboards')); ?>" class="type_card">
      <p class="type_card__title">Keyboards</p>
    </a>
    <a href="<?php echo e(url('/products/category/microphones')); ?>" class="type_card">
      <p class="type_card__title">Microphones</p>
    </a>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\GitHubDesktop\Team-Project\GamerHub\resources\views/products/index.blade.php ENDPATH**/ ?>