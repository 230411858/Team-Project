<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(url('/css/order.css')); ?>">
<style>
    #change-status-label {
        display: inline-block;
        width: 8em;
        padding-top: 1.5em;
    }

    #change-status {
        display: inline-block;
        width: 6em;
        position: relative;
        top: -3em;
        all: initial;
        font-family: 'Courier New', Courier, monospace;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
<title>My Order | GAMERHUB</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="order-box">
    <h1>Order #<?php echo e($order->id); ?> <span style="float: right;"><?php echo e($order->created_at); ?></span></h1>
    <hr>
    <h2><?php echo e($order->first_name); ?> <?php echo e($order->last_name); ?></h2>
    <h2><?php echo e($order->email); ?></h2>
    <h1>Address</h1>
    <hr>
    <h2><?php echo e($order->address_line_1); ?></h2>
    <h2><?php echo e($order->address_line_2); ?></h2>
    <h2><?php echo e($order->city); ?></h2>
    <h2><?php echo e($order->country); ?></h2>
    <h2><?php echo e($order->postcode); ?></h2>
    <h2><?php echo e($order->phone_number); ?></h2>
    <div class="order-status">
        <?php switch($order->status):

        case ('in-transit'): ?>
        <img class="order-status-image" src="<?php echo e(url('/images/in-transit.svg')); ?>" alt="">
        <h1 class="update-text">Your order is on your way to you now
            <span id="updated-at">(Last updated <?php echo e($order->updated_at); ?>)</span>
        </h1>
        <?php break; ?>
        <?php case ('delivered'): ?>
        <img class="order-status-image" src="<?php echo e(url('/images/delivered.svg')); ?>" alt="">
        <h1 class="update-text">Your order has been delivered
            <span id="updated-at">(Last updated <?php echo e($order->updated_at); ?>)</span>
        </h1>
        <?php break; ?>
        <?php default: ?>
        <img class="order-status-image" src="<?php echo e(url('/images/processing.svg')); ?>" alt="">
        <h1 class="update-text">We are curently processing your order
            <span id="updated-at">(Last updated <?php echo e($order->updated_at); ?>)</span>
        </h1>
        <?php break; ?>
        <?php endswitch; ?>
    </div>
    <hr>
    <?php
    $order_items = App\Models\OrderItem::where('oid', $order->id)->get();

    $products = App\Models\Product::all();

    $product_images = App\Models\ProductImage::all();

    $shipping_cost = $order->shipping_method == 'standard' ? 299 : 499;

    $subtotal = 0;
    ?>
    <?php $__currentLoopData = $order_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
    $product = $products->firstWhere('id', $order_item->product);

    $product_image = $product_images->firstWhere('product', $product->id);

    $subtotal += ($product->price * (1 - $order_item->discount) * $order_item->quantity);

    $discount_amount = 0;
    ?>
    <div class="order-item-overview">
        <img class="order-item-image" src="<?php echo e(url('/images')); ?>/<?php echo e($product->category); ?>/<?php echo e($product_image == null ? 'cover.png' : $product_image->file); ?>" alt="Product Image">
        <div class="order-item-text">
            <?php echo e(ucwords($product->name)); ?>

            <br>
            <i>
                (<?php echo e(ucwords($product->sub_category)); ?>, <?php echo e(ucwords($product->category)); ?>)
            </i>
            <br>
            <?php if($product->discount > 0): ?>
            <s>
                £<?php echo e(number_format($product->price / 100, 2)); ?>

            </s>
            <b class="discounted-price">
                £<?php echo e(number_format(($product->price * (1-$order_item->discount)) / 100, 2)); ?>

            </b>
            <?php else: ?>
            <b>
                £<?php echo e(number_format($product->price / 100, 2)); ?>

            </b>
            <?php endif; ?>
            <br>
            <p>
                Quantity: <?php echo e($order_item->quantity); ?>

            </p>
            <br>
            <br>
            <p id="product-id">
                #<?php echo e($product->id); ?>

            </p>
            <a id="product-link" href="<?php echo e(url('/products')); ?>/<?php echo e($product->id); ?>">View product</a>
        </div>
        <div class="order-item-subtotal">
            £<?php echo e(number_format(($product->price * (1-$order_item->discount) * $order_item->quantity) / 100, 2)); ?>

        </div>
    </div>
    <hr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="order-item-overview">
        <?php if(Auth::user()->account_type === 'admin'): ?>
        <label id="change-status-label" for="change-status">Update order status:</label>
        <br>
        <select onchange="edit(<?php echo $order->id ?>, this)" name="change-status" id="change-status">
            <option value="<?php echo $order->status ?>">No change</option>
            <option value="processing">Processing</option>
            <option value="in-transit">In-transit</option>
            <option value="delivered">Delivered</option>
        </select>
        <?php endif; ?>
        <div class="final-values-titles">
            <p class="subtotal">
                Subtotal
            </p>
            <p class="discount-amount">
                Discount
            </p>
            <p class="shipping-cost">
                Shipping (<?php echo e(ucwords($order->shipping_method)); ?>)
            </p>
            <p class="grand-total">
                Total
            </p>
        </div>
        <div class="final-values">
            <p class="subtotal">
                £<?php echo e(number_format($subtotal / 100, 2)); ?>

            </p>
            <p class="discount-amount">
                £-<?php echo e(number_format($discount_amount, 2)); ?>

            </p>
            <p class="shipping-cost">
                £<?php echo e(number_format(($shipping_cost) / 100, 2)); ?>

            </p>
            <p class="grand-total">
                £<?php echo e(number_format(($subtotal - $discount_amount + $shipping_cost) / 100, 2)); ?>

            </p>
        </div>
    </div>
    <hr>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(url('/js/orders.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\GitHubDesktop\Team-Project\GamerHub\resources\views/orders/show.blade.php ENDPATH**/ ?>