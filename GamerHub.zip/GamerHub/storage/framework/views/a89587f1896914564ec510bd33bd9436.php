<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Inventory Management')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="content-section">
        <div class="container">
            <div class="card">
                <div class="card-body">
                    <h3 class="section-title">Product Inventory</h3>

                    <?php if(session('success')): ?>
                        <p class="success-message"><?php echo e(session('success')); ?></p>
                    <?php endif; ?>

                    <table class="inventory-table">
                        <thead>
                        <tr>
                            <th>Product</th>
                            <th>Stock</th>
                            <th>Price</th>
                            <th>Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    
                                    <a href="<?php echo e(route('admin.products.show', $product->id)); ?>" class="product-link">
                                        <?php echo e($product->name); ?>

                                    </a>

                                </td>
                                <td>
                                    <?php if($product->stock <= 0): ?>
                                        <span class="out-of-stock">Out of Stock</span>
                                    <?php elseif($product->stock <= 5): ?>
                                        <span class="low-stock">Low Stock (<?php echo e($product->stock); ?>)</span>
                                    <?php else: ?>
                                        <?php echo e($product->stock); ?>

                                    <?php endif; ?>
                                </td>
                                <td>£<?php echo e(number_format($product->price / 100, 2)); ?></td>
                                <td>
                                    <a href="<?php echo e(route('admin.inventory.edit', $product->id)); ?>" class="edit-button">Edit</a>
                                    |
                                    <form action="<?php echo e(route('admin.inventory.delete', $product->id)); ?>" method="POST" class="inline-form">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" onclick="return confirm('Are you sure?')" class="delete-button">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <style>
        .content-section {
            padding: 40px 0;
        }

        .container {
            max-width: 1200px;
            margin: auto;
            padding: 0 20px;
        }

        .card {
            background: white;
            border-radius: 8px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }

        .card-body {
            padding: 20px;
        }

        .section-title {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 20px;
        }

        .success-message {
            color: green;
            font-weight: bold;
            margin-bottom: 15px;
        }

        .inventory-table {
            width: 100%;
            border-collapse: collapse;
        }

        .inventory-table th,
        .inventory-table td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }

        .inventory-table th {
            background: #f8f8f8;
        }

        .low-stock {
            color: #ff9800;
            font-weight: bold;
        }

        .out-of-stock {
            color: #d32f2f;
            font-weight: bold;
        }

        .edit-button, .delete-button {
            padding: 6px 12px;
            border-radius: 5px;
            text-decoration: none;
            cursor: pointer;
            transition: background 0.3s ease-in-out;
        }

        .edit-button {
            color: white;
            background-color: #007bff;
        }

        .edit-button:hover {
            background-color: #0056b3;
        }

        .delete-button {
            color: white;
            background-color: #dc3545;
            border: none;
        }

        .delete-button:hover {
            background-color: #c82333;
        }

        .inline-form {
            display: inline;
        }

        .product-link {
            color: #007bff;
            text-decoration: none;
            font-weight: bold;
        }

        .product-link:hover {
            text-decoration: underline;
            color: #0056b3;
        }
    </style>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\GitHubDesktop\Team-Project\GamerHub\resources\views/admin/inventory/index.blade.php ENDPATH**/ ?>