<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(url('/css/category.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
<title><?php echo e(ucfirst($category)); ?> | GAMERHUB</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-----MAIN BODY implemented by Isa Abdur-Rahman line ------>
<section id="pagebody">
    <div id="pagebody-top">
        <div id="productwrapper">
            <div id="textsection">
                <h2><?php echo e(ucfirst($category)); ?></h2>
                <p>Traverse through the top of the range <?php echo e($category); ?>, making navigation easy</p>
                <?php if(!Auth::check()): ?>
                <button id="signup-button" onclick="location.href='/register'">
                    SIGN UP NOW
                </button>
                <?php endif; ?>
            </div>
            <div id="imagesection">
                <img src="<?php echo e(url('/images')); ?>/<?php echo e($category); ?>/cover.png" alt="Wireless Black Mouse">
            </div>
        </div>
    </div>
</section>

<section id="productsmice">
    <div class="page-layout">
        <div class="filtersection">
            <?php switch($category):

            case ('mice'): ?>
            <div class="category">
                <h3>Category</h3>
                <button class="active" data-name="all">Show all</button>
                <button data-name="wireless">Wireless</button>
                <button data-name="wired">Wired</button>
                <button data-name="ergonomic">Ergonomic</button>
                <button data-name="stylus">Stylus</button>
                <button data-name="gaming">Gaming</button>
            </div>
            <?php break; ?>
            <?php case ('keyboards'): ?>
            <div class="category">
                <h3>Category</h3>
                <button class="active" data-name="all">Show all</button>
                <button data-name="membrane">Membrane</button>
                <button data-name="mechanical">Mechanical</button>
            </div>
            <?php break; ?>
            <?php case ('monitors'): ?>
            <div class="category">
                <h3>Category</h3>
                <button class="active" data-name="all">Show all</button>
                <button data-name="144hz">144hz</button>
                <button data-name="240hz">240hz</button>
            </div>
            <?php break; ?>
            <?php case ('speakers'): ?>
            <div class="category">
                <h3>Category</h3>
                <button class="active" data-name="all">Show all</button>
                <button data-name="bookshelf">Bookshelf</button>
                <button data-name="soundbar">Soundbar</button>
            </div>
            <?php break; ?>
            <?php case ('microphones'): ?>
            <div class="category">
                <h3>Category</h3>
                <button class="active" data-name="all">Show all</button>
                <button data-name="condenser">Condenser</button>
                <button data-name="dynamic">Dynamic</button>
            </div>
            <?php break; ?>
            <?php default: ?>
            <div class="category">
                <h3>Category</h3>
                <button class="active" data-name="all">Show all</button>
                <button data-name="no-category">No category defined!</button>
            </div>
            <?php break; ?>
            <?php endswitch; ?>
            <div class="price">
                <h3>Price</h3>
                <button class="active" data-price="all">Show all</button>
                <button data-price="10.00-19.99">£10 - £20</button>
                <button data-price="20.00-39.99">£20 - £40</button>
                <button data-price="40.00-59.99">£40 - £60</button>
                <button data-price="60.00-79.99">£60 - £80</button>
                <button data-price="80.00-">£80+</button>
            </div>
        </div>

        <div class="productcontainer">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $image = $images->firstWhere('product', $product->id);
            ?>
            <div class="products" data-name="<?php echo e($product->sub_category); ?>" data-price="<?php echo e(number_format((($product->price * (1 - $product->discount)) / 100), 2)); ?>">
                <a href="<?php echo e(url('/products')); ?>/<?php echo e($product->id); ?>">
                    <img src="<?php echo e(url('/images')); ?>/<?php echo e($category); ?>/<?php echo e($image == null ? 'cover.png' : $image->file); ?>">
                </a>
                <h5><?php echo e(ucwords($product->name)); ?></h5>
                <div class="star">
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                </div>
                <?php if($product->discount > 0): ?>
                <h4 class="discount-price">£<?php echo e(number_format((($product->price * (1 - $product->discount)) / 100), 2)); ?></h4>
                <?php else: ?>
                <h4>£<?php echo e(number_format(($product->price / 100), 2)); ?></h4>
                <?php endif; ?>
                <a href="<?php echo e(url('/add')); ?>/<?php echo e($product->id); ?>" class="cart-icon">
                    <i class="fa-solid fa-cart-shopping"></i>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(url('/js/category.js')); ?>"></script>
<script src="https://kit.fontawesome.com/6d6a721856.js" crossorigin="anonymous"></script>
<script async>
    document.addEventListener("DOMContentLoaded", function() {
        const subCategory = "<?php echo $sub_category ?>";
        document.querySelector(`[data-name="${subCategory}"]`).click();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\GitHubDesktop\Team-Project\GamerHub\resources\views/products/category.blade.php ENDPATH**/ ?>