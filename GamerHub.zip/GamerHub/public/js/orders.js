function edit(id, type)
{
    window.location.href = `/orders/${id}/${type.value}`;
}